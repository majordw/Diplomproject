import PyQt5.QtWidgets as qw
from PyQt5 import uic
# relativistische Physik
from model.ferdi import geschwAdd as Ferdi
from model.ferdi import ZeitGui as Ferdi2
#Trigonometrie
from model.sin_cos import main as Marat
# Chemie
from model.Periodensystem import periocdic_gui as Manuel
from model.Periodensystem import periodic_manager as manage
# Mechanische Physik
from model.tim import interfaceV2_Fall_end as Tim1
from model.tim import interfaceV2_schrWurf_end as Tim2
from model.tim import interfaceV2_waWurf_end as Tim3

class MainMenu(qw.QMainWindow):

    def __init__(self):
        super(MainMenu, self).__init__()
        uic.loadUi("model/menu.ui", self)
        self.setWindowTitle('Lernprogramm')
        self.bg_frame.setStyleSheet("""
        background-image: url(model/TGM_Logo.png);
        background-repeat: no-repeat;
        background-position: center""")

        # relativistische Physik
        self.pushButton.clicked.connect(lambda: self.changeUI(Ferdi.MyGUI))
        self.pushButton_5.clicked.connect(lambda: self.changeUI(Ferdi2.MyGUI))

        #Trigonometrie
        self.pushButton_2.clicked.connect(lambda: self.changeUI(Marat.ApplicationWindow))

        # Chemie (Disabled -> Z.54)
        self.pushButton_3.clicked.connect(lambda: self.changeToSuda(Manuel.Gui))
        self.pushButton_3.setDisabled(True)

        # Mechanische Physik
        self.pushButton_4.clicked.connect(lambda: self.changeUI(Tim1.MyGUI))
        self.pushButton_6.clicked.connect(lambda: self.changeUI(Tim2.MyGUI))
        self.pushButton_7.clicked.connect(lambda: self.changeUI(Tim3.MyGUI))

    def changeUI(self, gui):
        self.window = gui()
        self.window.show()
        self.close()

    # Error
    def changeToSuda(self, gui):
        self.changeUI(gui)
        self.manager = manage.Manager(self.window)
        self.manager.initConectors()
        # The event loop is already running
        self.manager.mainGameLoop()
        ###################################

def main():
    app = qw.QApplication([])
    #app.setStyle('Fusion')
    window = MainMenu()
    window.show()
    app.exec_()

if __name__ == '__main__':
    main()